using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.2D.Animation.Runtime")]
[assembly: InternalsVisibleTo("Unity.2D.Animation.Editor")]
[assembly: InternalsVisibleTo("Unity.2D.Animation.Tests.RuntimeTests")]
[assembly: InternalsVisibleTo("Unity.2D.IK.Editor")]
