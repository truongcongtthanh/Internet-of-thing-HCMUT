using NUnit.Framework;

namespace UnityEngine.U2D
{
    internal class PixelPerfectCameraEditorTests
    {
        [Test]
        public void PlaceHolderTest()
        {
            Assert.Pass("This is a placeholder to ensure we have at least one editor test.");
        }
    }
}
